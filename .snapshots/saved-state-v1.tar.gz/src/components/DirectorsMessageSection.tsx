import { motion } from 'motion/react';
import { COMPANY_INFO } from '../data/jjpData';
import ParallaxImage from './ParallaxImage';

export default function DirectorsMessageSection() {
  const leadDirector = COMPANY_INFO.directors[0];

  return (
    <section className="bg-white text-[#071B3D] py-16 lg:py-24">
      <div className="w-full max-w-[1800px] mx-auto px-5 sm:px-8 lg:px-12 xl:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          {/* LEFT — Minimal Architectural Visual & Leadership Attribution */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-4 relative bg-[#071B3D] text-white overflow-hidden"
          >
            <div className="relative h-56 lg:h-64 overflow-hidden">
              <ParallaxImage
                src="/assets/jjp/geo_solar.jpg"
                alt="Solar photovoltaic infrastructure engineered by Jerry John Powers"
                className="w-full h-full"
                intensity={8}
                scale={1.16}
              />
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  background:
                    'linear-gradient(to top, #071B3D 0%, rgba(7,27,61,0.4) 60%, rgba(7,27,61,0.15) 100%)',
                }}
              />
            </div>

            <div className="px-7 pb-7 pt-2">
              <div className="text-[12.5px] font-medium text-[#8BC6FF]">
                Board of Directors · Est. 2012
              </div>
              <div className="mt-2 font-serif text-[22px] font-medium text-white">
                {COMPANY_INFO.directors.map((d) => d.name).join(' & ')}
              </div>
              <div className="mt-1 text-[13px] text-[#C5D0DF]">
                Jerry John Powers Private Limited · Chennai
              </div>
            </div>
          </motion.div>

          {/* RIGHT — Spacious, Minimal Editorial Quote */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.65, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-8 lg:pl-6"
          >
            <h2 className="font-serif text-[28px] lg:text-[34px] font-medium text-[#071B3D] tracking-[-0.01em]">
              Director’s Message
            </h2>

            <blockquote className="mt-6">
              <p className="font-serif italic text-[22px] sm:text-[26px] lg:text-[31px] text-[#071B3D] leading-[1.45] max-w-[880px]">
                “{leadDirector.quote}”
              </p>
              <footer className="mt-6 flex items-center gap-3 text-[14.5px]">
                <span className="font-semibold text-[#071B3D]">{leadDirector.name}</span>
                <span className="text-[#94A3B8]" aria-hidden="true">
                  ·
                </span>
                <span className="text-[#475569]">Director, {COMPANY_INFO.name}</span>
              </footer>
            </blockquote>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
