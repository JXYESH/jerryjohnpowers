import { motion } from 'motion/react';
import { OVERVIEW_STATS } from '../data/jjpData';
import ParallaxImage from './ParallaxImage';

export default function CompanyOverview() {
  return (
    <section className="bg-[#F4F6F9] text-[#071B3D] pt-16 pb-20 lg:pt-24 lg:pb-28">
      <div className="w-full max-w-[1800px] mx-auto px-5 sm:px-8 lg:px-12 xl:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          {/* LEFT — Open Editorial Copy & Unboxed Hairline Statistics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <h2 className="font-serif text-[32px] lg:text-[42px] font-medium text-[#071B3D] leading-[1.16] tracking-[-0.01em]">
              Company Overview
            </h2>

            <p className="mt-5 text-[15.5px] text-[#475569] leading-[1.75]">
              Jerry John Powers Private Limited is a Chennai-headquartered solar energy and power
              infrastructure company serving Tamil Nadu and South India since 2012. We deliver
              customized rooftop, ground-mounted, and utility-scale solar plants for commercial
              enterprises, industrial manufacturers, universities, and hospitals.
            </p>

            {/* Open Unboxed Statistics Separated by Crisp Vertical Hairlines */}
            <div className="mt-9 pt-7 pb-7 border-y border-[#CBD5E1] grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-0 sm:divide-x sm:divide-[#CBD5E1]">
              {OVERVIEW_STATS.map((stat, idx) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.45, delay: idx * 0.08, ease: [0.16, 1, 0.3, 1] }}
                  className={idx > 0 ? 'sm:pl-7 sm:pr-4' : 'sm:pr-6'}
                >
                  <div className="text-[34px] lg:text-[40px] font-medium text-[#2389E8] leading-none tabular-nums">
                    {stat.value}
                  </div>
                  <div className="mt-2.5 text-[13.5px] font-medium text-[#475569] leading-[1.45]">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>

            <p className="mt-8 text-[15px] text-[#475569] leading-[1.75]">
              India’s leading corporates, MNCs, and institutions trust our engineering teams from
              initial concept, land identification, and TANGEDCO technical feasibility through
              substation commissioning, multi-storey electrical safety clearances, and long-term
              operations and maintenance.
            </p>
          </motion.div>

          {/* RIGHT — Unboxed Full-Bleed Parallax Solar Infrastructure Photograph */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <ParallaxImage
              src="/assets/jjp/biz_panels_2.jpg"
              alt="Grid-connected ground-mounted solar array and power control station"
              className="w-full h-[340px] sm:h-[420px] lg:h-[470px] shadow-[0_24px_60px_rgba(7,27,61,0.14)]"
              intensity={12}
              scale={1.2}
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
