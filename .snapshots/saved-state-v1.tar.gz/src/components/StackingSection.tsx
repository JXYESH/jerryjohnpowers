import { ReactNode, useEffect, useRef, useState } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react';

interface StackingSectionProps {
  children: ReactNode;
  zIndex: number;
  anchorId?: string;
  className?: string;
}

/**
 * Selective stacking layer: only pins when desktop viewport >= section height
 * so no content, card, or expandable area is ever hidden or clipped.
 */
export default function StackingSection({
  children,
  zIndex,
  anchorId,
  className = '',
}: StackingSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [canStack, setCanStack] = useState<boolean>(false);
  const prefersReduced = useReducedMotion();

  useEffect(() => {
    const checkFit = () => {
      if (!sectionRef.current) return;
      const isDesktop = window.innerWidth >= 1024;
      const fitsViewport = sectionRef.current.offsetHeight <= window.innerHeight * 0.98;
      setCanStack(isDesktop && fitsViewport);
    };

    checkFit();
    const observer = new ResizeObserver(checkFit);
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    window.addEventListener('resize', checkFit);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', checkFit);
    };
  }, []);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end start'],
  });

  const scale = useTransform(
    scrollYProgress,
    [0, 1],
    prefersReduced || !canStack ? [1, 1] : [1, 0.965]
  );
  const overlayOpacity = useTransform(
    scrollYProgress,
    [0, 1],
    prefersReduced || !canStack ? [0, 0] : [0, 0.22]
  );

  return (
    <>
      {anchorId && (
        <div
          id={anchorId}
          aria-hidden="true"
          className="h-0 w-full pointer-events-none"
        />
      )}
      <div
        ref={sectionRef}
        style={{ zIndex }}
        className={`relative ${
          canStack && !prefersReduced ? 'lg:sticky lg:top-0' : ''
        } ${className}`}
      >
        <motion.div
          style={{
            scale,
            transformOrigin: 'top center',
            willChange: canStack ? 'transform' : undefined,
          }}
          className="relative"
        >
          {children}
          {canStack && !prefersReduced && (
            <motion.div
              aria-hidden="true"
              style={{ opacity: overlayOpacity }}
              className="pointer-events-none absolute inset-0 bg-[#05142E] z-40"
            />
          )}
        </motion.div>
      </div>
    </>
  );
}
