import { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import OverlappingPanels from './components/OverlappingPanels';
import CompanyOverview from './components/CompanyOverview';
import ClientsMarquee from './components/ClientsMarquee';
import ExpertiseSection from './components/ExpertiseSection';
import ProjectsSection from './components/ProjectsSection';
import DirectorsMessageSection from './components/DirectorsMessageSection';
import ContactFooter from './components/ContactFooter';
import ProjectDetailModal from './components/ProjectDetailModal';
import StackingSection from './components/StackingSection';
import { SolarProject } from './data/jjpData';

export default function App() {
  const [selectedProject, setSelectedProject] = useState<SolarProject | null>(null);
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<string>('home');

  useEffect(() => {
    const sections = ['home', 'overview', 'services', 'projects', 'contact'];
    const handleScroll = () => {
      const scrollPos = window.scrollY + 180;
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSelectExpertise = (serviceId: string) => {
    setSelectedServiceId(serviceId);
    const el = document.getElementById('services');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#071B3D] text-white flex flex-col overflow-x-clip">
      <main className="flex-1 relative">
        {/* Hero + Signature Overlapping Panels */}
        <div id="home" className="relative z-10">
          <Navbar activeSection={activeSection} />
          <HeroSection />
          <OverlappingPanels
            onSelectProject={setSelectedProject}
            onSelectExpertise={handleSelectExpertise}
          />
        </div>

        {/* Company Overview (Selective Stacking) */}
        <StackingSection anchorId="overview" zIndex={20}>
          <CompanyOverview />
        </StackingSection>

        {/* Prominent Moving Clients & EPC Collaborations Strip Right Below Overview */}
        <div className="relative z-30 shadow-[0_-18px_45px_rgba(4,16,38,0.12)]">
          <ClientsMarquee />
        </div>

        {/* Capabilities & Projects */}
        <div id="services" className="relative z-30">
          <ExpertiseSection externalSelectedId={selectedServiceId} />
        </div>

        <div id="projects" className="relative z-30">
          <ProjectsSection onSelectProject={setSelectedProject} />
        </div>

        {/* Minimal Director's Message (Selective Stacking) */}
        <StackingSection anchorId="leadership" zIndex={40}>
          <DirectorsMessageSection />
        </StackingSection>

        {/* Minimal Closing Contact & Quiet Footer */}
        <div
          id="contact"
          className="relative z-50 shadow-[0_-24px_60px_rgba(4,16,38,0.32)]"
        >
          <ContactFooter />
        </div>
      </main>

      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </div>
  );
}
